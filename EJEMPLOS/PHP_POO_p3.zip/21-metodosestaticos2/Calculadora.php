<?php
class Calculadora {
    public static function sumar($v1, $v2) {
        return $v1+$v2;
    }

    public static function restar($v1, $v2) {
        return $v1-$v2;
    }

    public static function multiplicar($v1, $v2) {
        return $v1*$v2;
    }

    public static function dividir($v1, $v2) {
        return $v1/$v2;
    }
}
?>